<template>
  <div id="home-wrap" class="home-wrap">
    <div
      v-for="item in moduleList"
      :key="item.name"
      class="module-wrap"
    >
      <div class="module-title">
        {{ item.name }}
      </div>
      <div class="module-content">
        <div
          v-for="menu in item.menuList"
          :key="menu.name"
          class="menu-wrap"
        >
          <div class="img-wrap">
            <img :src="defaultImg" class="h100 w100">
          </div>
          <div>{{ menu.name }}</div>
        </div>
      </div>
    </div>
    <!--<Loading id="home-wrap" :loading="true" />-->
  </div>
</template>
<script>
import { setToken, setUserInfo } from '@/utils/tool'
import { getAuthUserInfo } from '@/utils/auth-api'

const defaultImg = require('@/assets/img/img_logo_240x240.png')

export default {
  data() {
    return {
      defaultImg,
      moduleList: [
        {
          name: '工作日报',
          menuList: [
            {
              name: '填日报'
            }
          ]
        },
        {
          name: '审批',
          menuList: [
            {
              name: '发起审批'
            },
            {
              name: '我提交的'
            },
            {
              name: '我审过的'
            },
            {
              name: '我的待审'
            }
          ]
        }
      ]
    }
  },
  mounted() {
    const code = this.$route.query.code
    if (code) {
      this.getTokenAndUserInfo(code)
    }
  },
  methods: {
    getTokenAndUserInfo(code) {
      getAuthUserInfo(code).then(({ data }) => {
        if (data && data.code === 0) {
          setToken(data.entity.token)
          setUserInfo(data.entity.userInfo)
        }
      })
    }
  }
}
</script>
<style lang="less" scoped>
.home-wrap {
  position: relative;
  padding: 10px;
  .module-wrap {
    padding: 10px;
    box-shadow: 0px 0px 4px 1px lightgray;
    margin-bottom: 20px;
    .module-title {
      font-size: 16px;
      font-weight: bold;
    }
    .module-content {
      padding: 10px;
      display: flex;
      flex-flow: wrap;
      .menu-wrap {
        width: 33.3%;
        text-align: center;
        margin-bottom: 10px;
        .img-wrap {
          width: 50px;
          height: 50px;

          margin: 0 auto;
        }
      }
    }
  }
}
</style>

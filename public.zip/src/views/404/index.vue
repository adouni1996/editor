<template>
  <div class="page pc">
    <div class="container">
      pc classs
    </div>
  </div>
</template>

<script>
export default {

}
</script>

<style lang="less" scoped>
.pc{
  font-size:16px;
  .container{
    padding: 20px;
  }

}
</style>

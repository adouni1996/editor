<template>
  <div class="approval-process card">
    审批流程
  </div>
</template>

<script>
export default {

}
</script>

<style>

</style>

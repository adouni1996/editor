<template>
  <div class="top fl ac js">
    <div class="left fl ac">
      <XhLabel text="生产" type="main" />
      <span class="code">{{ `${ code }_生产计划` }}</span>
    </div>
    <div class="right">
      <XhSwitch v-model="tempType" />
    </div>
  </div>
</template>

<script>
export default {
  props: {
    code: {
      type: String,
      default: ''
    },
    type: {
      type: String,
      default: ''
    }
  },
  data: () => ({
    tempType: ''
  }),
  watch: {
    type: {
      handler(val) {
        this.tempType = val
      },
      immediate: true
    },
    tempType: {
      handler(val) {
        this.$emit('update:type', val)
      }
    }
  }
}
</script>

<style lang="less" scoped>
.top{
  .left{

    .xh-label{
      padding: 2px 4px;
    }
    .code{
      margin-left: 6px;
      word-break:break-all;
    }
  }
  .right{
    min-width: 100px;
    text-align: right;
  }
}
</style>

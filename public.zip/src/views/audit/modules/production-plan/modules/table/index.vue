<template>
  <div class="table">
    <XhTable
      :table-body="tableBody"
      :table-data="tableData"
    >
      <template #header="headerData">
        {{ headerData.data.name }}({{ tableData.length }})
      </template>
      <template #default="val">
        <template v-if="val.item.key==='num'">
          {{ Number(val.row.num).toLocaleString() }}
        </template>
      </template>
    </XhTable>
  </div>
</template>

<script>
export default {
  props: {
    tableData: {
      type: Array,
      default: () => []
    }
  },
  data: () => ({
    tableBody: [
      { key: 'type', name: '产品类别', width: 'auto', handler: false, show: true, customizeHeader: true },
      { key: 'num', name: '数量', width: '20%', handler: true, show: true, customizeHeader: false, alignment: 'right' },
      { key: 'time', name: '完成时间', width: '20%', handler: false, show: true, customizeHeader: false, alignment: 'right' }
    ]
  })
}
</script>

<style lang="less" scoped>
.table{
  margin-top: 11px;
}
</style>

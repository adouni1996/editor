<template>
  <div class="production-plan card">
    <Top code="XH20220" :type.sync="type" />
    <Table :table-data="tableData" />
  </div>
</template>

<script>
import Top from './modules/top'
import Table from './modules/table'
export default {
  components: {
    Top,
    Table
  },
  data: () => ({
    type: 'synopsis',
    tableData: [
      { time: '12/10', num: 12313, type: 'XianD款分体4键' },
      { time: '12/10', num: 12313, type: 'Xian.D款(分体3+1键)' },
      { time: '12/10', num: 12313, type: 'FENG.T款(分体4键)' },
      { time: '12/10', num: 12313, type: 'FENG.T款(折叠3键)' }
    ]
  })
}
</script>

<style>

</style>

<template>
  <div class="top fl ac js">
    <div class="left fl ac">
      <img :src="img">
      <span class="title">
        {{ title }}
      </span>
    </div>
    <div class="right">
      <XhStatus text="待审批" />
    </div>

  </div>
</template>

<script>
export default {
  props: {
    img: {
      type: String,
      default: ''
    },
    title: {
      type: String,
      default: ''
    },
    status: {
      type: String,
      default: ''
    },
    statusText: {
      type: String,
      default: ''
    }
  }
}
</script>

<style lang="less" scoped>
.top{
  padding:10px 15px;
  background-color: #fff;
  .left{
    img{
      width: 40px;
      height: 40px;
      border-radius: 4px;
      object-fit: cover;
    }
    .title{
      margin-left: 9px;
      font-size: 16px;
    }
  }
  .right{
    min-width: 70px;
    text-align: right;
  }
}
</style>

<template>
  <div class="btn fl ac js">
    <div
      v-for="(item,index) in btnList"
      :key="index"
      class="item fl ac jc"
    >
      <svg-icon :icon-class="item.svg" />
      <span class="text">{{ item.name }}</span>
    </div>
  </div>
</template>

<script>
export default {
  data: () => ({
    btnList: [
      { svg: 'btn_approval_more', key: 'more', name: '更多' },
      { svg: 'btn_approval_reject', key: '', name: '驳回' },
      { svg: 'btn_approval_agree', key: '', name: '同意' }
    ]
  })
}
</script>

<style lang="less" scoped>
.btn{
  margin-top: 8px;
  border-top: 1px solid  #F0F0F0;;
  padding: 7px 0;
  .item{
    height: 40px;
    svg{
      margin-right: 7px;
    }
    &:nth-of-type(1){
      color: #666666;
      svg{
        width: 14px;
        height: 14px;
      }

    }
    &:nth-of-type(2),
    &:nth-of-type(3){
      width: 128px;
      background: #F2F2F4;
      border-radius: 4px;
      svg{
        width: 12px;
        height: 12px;
      }
    }
    &:nth-of-type(2){
      color: #FF0000 ;
    }
    &:nth-of-type(3){
      color: #3656C6 ;
    }

  }
}
</style>

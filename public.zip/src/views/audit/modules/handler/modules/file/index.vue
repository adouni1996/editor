<template>
  <div class="file">
    <svg-icon icon-class="btn_approval_appendix" />
  </div>
</template>

<script>
export default {

}
</script>

<style lang="less" scoped>
.file{
  margin-top: 8px;
  svg{
    width: 32px;
    height: 32px;
  }
}
</style>

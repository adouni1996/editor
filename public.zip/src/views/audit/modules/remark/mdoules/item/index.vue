<template>
  <div class="item">
    <div class="top fl ac js">
      <div class="left fl ac">
        <img :src="img">
        <span class="name">小妹</span>
      </div>
      <div class="time">
        07/08 12:10
      </div>
    </div>
    <div class="container">
      “测试测试测试文字”
    </div>
  </div>
</template>

<script>
import img from '@/assets/img/img1.png'
export default {
  data: () => ({
    img
  })
}
</script>

<style lang="less" scoped>
.item{
  padding: 9px 12px;
  &:nth-of-type(2n-1){
    background: #F7F8FC;
  }
  .top{
    .left{
      img{
        width: 24px;
        height: 24px;
        border-radius: 6px;
      }
      .name{
        margin-left: 8px;
      }
    }
    .time{
      color: #999999;
      font-size: 12px;
      font-family: PingFangSC-Medium;
    }
  }
  .container{
    margin-top: 6px;
    padding-left: 32px;
    color: #878787;
    font-size: 12px;
  }
}
</style>

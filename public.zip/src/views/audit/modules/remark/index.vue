<template>
  <div class="remark card">
    <div v-if="remarkList.length ===0" class="add">
      添加备注
    </div>
    <div v-else class="container">
      <div class="top fl ac js">
        <div class="title">
          备注
        </div>
      </div>
      <div class="list">
        <Item
          v-for="(item,index) in remarkList"
          :key="index"
          :item="item"
        />
      </div>
    </div>
  </div>
</template>

<script>
import Item from './mdoules/item'
export default {
  components: {
    Item
  },
  props: {
    remarkList: {
      type: Array,
      default: () => []
    }
  }
}
</script>

<style lang="less" scoped>
.remark{
  padding: 0;
  padding-bottom: 28px;
  .add{
    padding: 12px;
    font-size: 16px;
    text-align: center;
    color: #3656C6;
  }
  .top{
    padding: 12px;
  }

}
</style>

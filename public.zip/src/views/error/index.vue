<template>
  <div class="error-wrap">
    <div>未拿到token或者token错误，请退出并联系管理员！</div>
  </div>
</template>
<script>
export default {}
</script>
<style lang='less' scoped>
.error-wrap {
  text-align: center;
  font-size: 20px;
  div {
    margin-top: 50%;
    transform: translateY(-50%);
  }
}
</style>

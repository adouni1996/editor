<template>
  <div class="auth-wrap">
    <div>授权跳转中...</div>
  </div>
</template>
<script>
import { getAuthToken } from '@/utils/auth-api'

export default {
  data() {
    return {}
  },
  mounted() {
    this.getToken()
  },
  methods: {
    getToken() {
      getAuthToken()
    }
  }
}
</script>
<style lang='less' scoped>
.auth-wrap {
  position: relative;
  font-size: 20px;
  text-align: center;
  div {
    margin-top: 50%;
    transform: translateY(-50%);
  }
}
</style>

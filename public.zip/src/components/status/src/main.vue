<template>
  <div
    :class="{
      'xh-status':true,
      [`xh-status-${ type }`]:true
    }"
  >
    {{ text }}
  </div>
</template>

<script>
export default {
  name: 'XhStatus',
  props: {
    text: {
      type: String,
      default: ''
    },
    type: {
      type: String,
      default: 'default'

    }
  }

}
</script>

<style lang="less" scoped>
.xh-status{
  display: inline-block;
  padding: 5px 7px;
  border-radius: 4px;
  font-size: 11px;
}
.xh-status-default{
  color: #fff;
  background: #3656C6;
}
</style>

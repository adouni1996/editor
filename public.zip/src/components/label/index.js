import Loading from './src/main'

Loading.install = function(Vue) {
  Vue.component(Loading.name, Loading)
}

export default Loading

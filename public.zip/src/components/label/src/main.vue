<template>
  <div
    :class="{
      'xh-label':true,
      [`xh-label-${ type }`]:true
    }"
  >
    {{ text }}
  </div>
</template>

<script>
export default {
  name: 'XhLabel',
  props: {
    text: {
      type: String,
      default: ''
    },
    type: {
      type: String,
      default: 'default' // success  main  default
    }
  }
}
</script>

<style lang="less" scoped>
.xh-label{
  display: inline-block;
  padding: 2px 6px;
  font-size: 14px;
  border-radius: 4px;
}
.xh-label-success{
  border: 1px solid #34C759;
  color:#34C759;
  background: rgba(57,207,95,0.24);

}
.xh-label-main{
  border: 1px solid #FF9500;
  color:#ff9500;
  background: rgba(255,149,0,0.24);

}
.xh-label-default{
  color: #3656C6;
  border: 1px solid #3656C6;
  background: rgba(54,86,198,0.30);
}
</style>

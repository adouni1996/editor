<template>
  <div class="table">
    <DxDataGrid
      ref="DxDataGrid"
      :data-source="tableData"
      :show-borders="true"
      row-template="dataRowTemplate"
      :selection="{
        mode:selectionMode
      }"
      :allow-reordering="false"
      :column-auto-width="true"
      height="100%"
    >
      <template v-for="(item, index) in tableBody">
        <DxColumn
          v-if="item.customizeHeader"
          :id="item.key"
          :key="index"
          :alignment="item.alignment || 'left'"
          :allow-sorting="false"
          :caption="JSON.stringify(item)"
          header-cell-template="headerTemplate"
          :css-class="`header-${ item.key } pr`"
          :width="item.width"
        />
        <DxColumn
          v-else
          :id="item.key"
          :key="index"
          :alignment="item.alignment || 'left'"
          :allow-sorting="false"
          :caption="item.name"
          :css-class="'pr'"
          :width="item.width"
        />
      </template>
      <template #headerTemplate="{data}">
        <slot :data="JSON.parse(data.column.caption)" name="header" />
      </template>
      <DxPaging :page-size="tableData.length" />
      <template #dataRowTemplate="{ data: rowInfo }">
        <tbody
          :class="{ 'dev-table-tbody': true }"
        >
          <tr
            :class="{
              'dev-table-tr-active':selectionMode!=='none' && selectIndex === rowInfo.rowIndex,
              'dev-table-tr': true,
              'dev-table-tr-border':!selectIndex,
              'dev-table-opacity': rowInfo.data[opacityKey]
            }"
            @click="rowClick(rowInfo)"
            @dblclick="dblClick(rowInfo.data,$event)"
          >
            <template v-for="(item, index) in tableBody">
              <td
                v-if="item.show"
                :id="`data-${ item.key }-${ rowInfo.rowIndex }`"
                :key="index"
                :class="{
                  'dev-table-td pr': true,
                  'dev-table-svg': item.key === 'imgUrl',
                  'dev-table-check': item.type === 'check',
                  'dev-table-noOpacity': item.type === 'noOpacity',
                  [`dev-table-alignment-${ item.alignment }`]: item.alignment
                }"
                @click.stop="tdClick({
                  id:`data-${ item.key }-${ rowInfo.rowIndex }`,
                  row:rowInfo.data,
                  rowIndex:rowInfo.rowIndex,
                  item
                })"
              >
                <template v-if="item.handler">
                  <slot :row="rowInfo.data" :item="item" :row-index="rowInfo.rowIndex" />
                </template>
                <template v-else>
                  {{ rowInfo.data[item.key] }}
                </template>
              </td>
            </template>
          </tr>
        </tbody>
      </template>
    </DxDataGrid>
  </div>
</template>

<script>
export default {
  name: 'XhTable',
  props: {
    selectionMode: {
      type: String,
      default: 'none'
    },
    tableData: {
      type: Array,
      default: () => []
    },
    tableBody: {
      type: Array,
      default: () => []
    },
    dblClick: {
      type: Function,
      default: () => () => {}
    },
    opacityKey: {
      type: String,
      default: ''
    },
    rowClick: {
      type: Function,
      default: () => () => {}
    },
    tdClick: {
      type: Function,
      default: () => () => {}
    }

  },
  data: () => ({
    selectIndex: ''
  }),
  methods: {
    async select(index) {
      this.selectIndex = index
    }
  }
}
</script>

<style lang="less" scoped>
.table{
  height: 100%;
  /deep/.dx-datagrid{
    font-size: 14px;
    color: #000;
    border-radius: 4px;
    overflow: hidden;
      .dx-datagrid-headers {
        border-top: 0;
        border-left: 0;
        border-right: 0;
        border-bottom: 1px solid #e1e5f1;
        background-color: #EDF0F9;
      }

     .dx-row > td {
        border-left:0;
        border-right:0;
      }
      .dx-datagrid-rowsview{
        border: 0;
      }
      .dx-datagrid-borders .dx-datagrid-headers .dx-datagrid-table {
        height: 32px;
        font-weight: 500;
      }
      .dev-table-tr.dev-table-tr-border {
        height: 32px;
        border: 0;
        .dev-table-td {
          padding: 8px 9px;
          word-break: break-all;
          white-space: normal;
          &:first-child {
            border-left: 0px;
          }
        }
        .dev-table-alignment-right{
          text-align: right;
        }
        .dev-table-td-nopadding {
          padding: 0 ;
        }
      }
      .dev-table-tbody.dx-template-wrapper {
        &:nth-child(2n) {
          .dev-table-tr.dev-table-tr-border {
            background: #F7F8FC;
          }
        }
      }

    }
  }

</style>

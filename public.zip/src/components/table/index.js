import Table from './src/main'

Table.install = function(Vue) {
  Vue.component(Table.name, Table)
}

export default Table

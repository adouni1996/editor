<template>
  <div class="xh-switch ">
    <div class="xh-switch-container fl ac">
      <div
        v-for="(item,index) in items"
        :ref="`item${ item.key }`"
        :key="index"
        :class="{
          'item':true,
          'active':item.key===value
        }"
        @click="change(item)"
      >
        {{ item.name }}
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'XhSwitch',
  props: {
    items: {
      type: Array,
      default: () => [
        { key: 'synopsis', name: '概要' },
        { key: 'all', name: '全部' }
      ]
    },
    value: {
      type: [Number, String],
      default: 'synopsis'
    }
  },
  methods: {
    change(item) {
      this.$emit('input', item.key)
    }
  }

}
</script>

<style lang="less" scoped>
.xh-switch{
  display: inline-block;
}
.xh-switch-container{
  padding: 2px;
  border-radius: 4px;
  background-color: #F0F0F0 ;
  .item{
    padding: 4px 6px;
    color: #999999;
    font-size: 11px;
    background-color:transparent;
    transition: all .3s;
  }
  .active{
    color: #3656C6 ;
    background: #FFFFFF;
    border-radius:3px ;
    box-shadow: 0px 0px 6px 0px rgba(0,0,0,0.12);
  }
}
</style>

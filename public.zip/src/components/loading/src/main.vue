<template>
  <DxLoadPanel
    :position="{of: `#${ id }`}"
    :visible="loading"
    shading-color="rgba(0,0,0,.2)"
  />
</template>

<script>
export default {
  name: 'XhLoading',
  props: {
    id: {
      type: String,
      default: ''
    },
    loading: {
      type: Boolean,
      default: false
    }
  }

}
</script>

<style>

</style>

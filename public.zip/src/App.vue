<template>
  <div id="app">
    <router-view />
  </div>
</template>

<style lang="less">
#app {
  font-size: 14px;
}
</style>

import Vue from 'vue'
import Router from 'vue-router'

Vue.use(Router)

const router = new Router({
  isGetRouter: false,
  routes: [
    {
      path: '/',
      name: 'layout',
      meta: { title: 'mobile-portal-layout' },
      component: () => import('@/layout')
    }
  ]
})

export default router

export default [
  {
    path: '/home',
    name: '首页'
  },
  {
    path: '/error',
    name: '错误'
  },
  {
    path: '/auth',
    name: '权限'
  },
  {
    path: '/404',
    name: '404'
  },
  {
    path: '/audit',
    name: '审批'
  }

]
// component: () => import(/* webpackChunkName: "error" */ '@/views/error')
